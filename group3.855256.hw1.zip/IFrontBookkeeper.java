package frontbookkeeper855256;

/**
 *
 * @author Tikhoglo
 */
public interface IFrontBookkeeper {
    String updateFront(String[] news);
}
